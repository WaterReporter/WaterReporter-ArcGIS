//
//  main.m
//  WebmapSample
//
//  Created by Sam Cunningham on 4/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WebmapSampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WebmapSampleAppDelegate class]));
    }
}
